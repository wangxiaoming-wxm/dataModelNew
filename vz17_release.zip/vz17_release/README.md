# vz17: 双臂 CatBoost (rsm 正则) + byte0 折内 TE

保险理赔预测比赛方案。二分类，AUC 评测。

> **这是实际提交过、真实验证的方案**，不是 OOF 预测。

## 结果

| 指标 | 值 |
|------|-----|
| **OOF AUC** | **0.70170** |
| **线上 AUC（实际提交）** | **0.71487** |
| OOF→online gap | 0.01317 |

### 诚实定位

- 本方案**完全自包含**：从 `train.csv`/`test.csv` 出发，两个 CatBoost 臂 + 一个 byte0 TE，没有任何外部依赖。
- 同比赛有一个略高的成绩 0.71503（W62），但它**依赖一个外部参考解的预训练 checkpoint**，无法从原始数据独立复现。
- **vz17 是从零开始可独立复现的最高分**（0.71487）。本包的目的就是让别人能完整跑通它。

## 方法概要

```
arm1 = CatBoost(build_main 特征, Ordered, d5, l2=10, rsm=1.0)   10fold × 8seed × 3bag
arm2 = CatBoost(build_alt  特征, Plain,   d6, l2=6,  rsm=0.3)   10fold × 8seed × 3bag   ← 关键
byte0 = id 哈希第 0 字节(0-255) 的折内 target encoding (5-fold)

fuse  = 0.64·rank(arm1) + 0.36·rank(arm2)                → OOF 0.70105
final = 0.98·fuse + 0.07·rank(byte0_TE)                  → OOF 0.70170
```

### 三个核心设计决策

1. **rsm=0.3（30% 特征子采样）用于 arm2**
   arm2 用 `build_alt`（rate 世界，~100 特征）。`rsm=0.3` 是关键正则化：扫描结果
   `0.3 > 0.5 > 0.25 > 0.4 > 1.0`，每个 seed 约 +0.002。
   （arm1 用 Ordered boosting，rsm=0.3 提升可忽略，故保持 rsm=1.0。）

2. **RMSE 回归而非分类 loss**
   Logloss/CrossEntropy 的 OOF ≈ 0.51（近随机），RMSE 回归 OOF ≈ 0.70。
   原因：标签是连续理赔额二值化的，回归 loss 更契合信号结构。

3. **byte0 折内 TE（仅 7% 权重）**
   id 哈希第 0 字节是 256 个离散值，对其做 5-fold target encoding。
   cross-half 20 次随机半子集：**19/20 次 AUC > 0.5**（mean 0.521，1 次跌到 0.499 属噪声），
   折内 TE OOF 0.519。是 train 内**弱但基本稳定**的真实信号。权重很小（7%），只做微调。

## 复现步骤

### 前置条件

```bash
pip install catboost scikit-learn scipy pandas numpy
```

数据文件（**不在本包内**，需自备）:
- `data/train.csv` (14930 行, 45 列, 含 `label`)
- `data/test.csv` (6398 行, 44 列)

### Step 1: 训练 arm1（~90 分钟）

```bash
cd src
python3 train_catboost.py --arm arm1 --data-dir ../data --out-dir ../checkpoints/arm1
```
输出：`checkpoints/arm1/arm1_seed{2040..2047}_{oof,te}.npy`

### Step 2: 训练 arm2（~120 分钟）

```bash
python3 train_catboost.py --arm arm2 --data-dir ../data --out-dir ../checkpoints/arm2
```
输出：`checkpoints/arm2/arm2_seed{2040..2047}_{oof,te}.npy`

### Step 3: 融合 + byte0 TE → submission

```bash
python3 build_vz17.py \
  --arm1-dir ../checkpoints/arm1 \
  --arm2-dir ../checkpoints/arm2 \
  --data-dir ../data \
  --out ../submission_vz17.csv
```
会打印各组件 OOF，并写入 `submission_vz17.csv`（6398 行）。

### Step 4: 验证 byte0 信号（可选，~10 秒）

```bash
python3 validate.py --data-dir ../data
```

## 文件结构

```
vz17_release/
├── README.md                 ← 本文件
├── requirements.txt
├── src/
│   ├── features.py           ← 特征工程 (build_main + build_alt)
│   ├── train_catboost.py     ← CatBoost 训练 (arm1 rsm=1.0 / arm2 rsm=0.3)
│   ├── build_vz17.py         ← 双臂 rank 融合 + byte0 TE → submission
│   └── validate.py           ← byte0 cross-half 稳定性验证
├── docs/
│   ├── METHOD.md             ← 方法详解
│   └── EVIDENCE.md           ← 实验证据 (rsm 扫描, byte0, gap 校准)
└── submission_vz17.csv       ← 最终提交文件 (线上 0.71487)
```

## 关键设计决策与证据

| 决策 | 证据 |
|------|------|
| RMSE 而非 Logloss | 分类 loss OOF≈0.51（近随机），RMSE≈0.70 |
| rsm=0.3 for arm2 | 扫描：0.3 > 0.5 > 0.25 > 0.4 > 1.0，每 seed +0.002 |
| 10fold 而非 5fold | 线上 +0.002 |
| byte0 TE w=0.07 | cross-half 19/20 > 0.5 (mean 0.521)；OOF 0.70105→0.70170 |
| arm1 rsm=1.0 | Ordered boosting 下 rsm=0.3 提升 < 0.0004，忽略 |

详见 `docs/EVIDENCE.md`。
