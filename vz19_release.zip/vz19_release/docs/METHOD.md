# 方法详解

## 1. 数据

| | 行数 | 列数 | 正例率 |
|---|---|---|---|
| Train | 14930 | 45 (含 label) | 10.02% |
| Test | 6398 | 44 | 未知 |

特征类型:
- **二值列** (8): t1, t2, r1, r2, c1, c2, w1, w2
- **连续列**: days, condition, age_range, cc, max_g, V, x17, x14, x19, x20 等
- **类别列**: region, source, month, version, grades, livability, t3, code
- **id**: 16 字符 hex (64 bit)

## 2. 特征工程

### 2.1 cond_r 世界 (`build_main`)

核心变换: `condition` 按 `source` 的中位数标准化 → `cond_r`
```
cond_r = condition / median(condition | source)
ratio = days / cond_r
```

衍生特征:
- log 变换: log_days, log_condition, log_cond_r, log_ratio
- 交互: cond_x_days, cond_over_days, days_over_age, ratio_p75
- 分箱 (quantile binning): days/ratio/cond_r 各分 5/10/20/40 档 → 类别列
- 比值: RATIO_COLS=['V','cc','max_g','x17','x14'] 各除以 cond_r
- **手工类别交叉** (~50 个): region×source, days_bin×region, cond_bin×source 等
  - 这些是模型信号的主要来源
  - CatBoost 的 max_ctr_complexity=1（不做自动组合），手工交叉是唯一捕捉交互的方式

输出: ~121 特征, 81 类别列

### 2.2 rate 世界 (`build_alt`)

核心变换: `condition` 按 `source` 的百分位排名 → `cond_rk`
```
cond_rk = rank_pct(condition | source)
rate = days × (1 - cond_rk)
```

用不同的分箱数 (7/13/25 而非 5/10/20/40) 和不同的交叉组合，保证与 `build_main` 的多样性。

输出: ~100 特征, ~60 类别列

### 2.3 为什么需要两个特征世界？

`build_main` (cond_r) 和 `build_alt` (rate) 对同一个 condition 列做了不同的标准化。
两者的 OOF 相关性 ~0.94，足够多样以从融合中获益。

## 3. 模型训练

### 3.1 为什么用 RMSE 而非分类 loss？

| Loss | OOF AUC |
|------|---------|
| **RMSE (回归)** | **0.70** |
| Logloss (分类) | 0.51 |
| CrossEntropy | 0.51 |

分类 loss 完全失败。原因: 数据有 81 个类别列，需要 CatBoost 的原生 CTR (category target ratio) 编码。
CTR 编码在分类 loss 下不稳定，但在 RMSE 回归下表现良好。
（参考解也用 RMSE，这不是选择而是必须。）

### 3.2 超参数

| 参数 | arm1 | arm2 | 理由 |
|------|------|------|------|
| boosting_type | Ordered | Plain | Ordered 对小数据更稳健 |
| depth | 5 | 6 | arm1 特征更多(121), 用浅树防过拟合 |
| l2_leaf_reg | 10 | 6 | arm1 更强正则 |
| rsm | 1.0 | 0.3 | **关键**: arm2 的 100 特征信号稀释, 30% 子采样是最优 |
| iterations | 800 | 800 | |
| learning_rate | 0.03 | 0.03 | |
| one_hot_max_size | 2 | 2 | 只对 2 值类别做 one-hot |
| random_strength | 0.7 | 0.7 | 分裂随机性 |

### 3.3 rsm 的发现

rsm (random subspace method) = 每次分裂只考虑 rsm 比例的特征。

```
扫描结果 (2-fold, Ordered d5 l2=10):
  rsm=0.3: OOF=0.7065  ← 最优
  rsm=0.5: OOF=0.7043
  rsm=0.25: OOF=0.7040
  rsm=0.4: OOF=0.7034
  rsm=1.0: OOF=0.7020  ← 默认
```

121 个特征中有大量噪声/冗余。rsm=0.3 相当于每棵树只用 30% 特征，
类似 Random Forest 的特征 bagging，有效降低方差。

### 3.4 交叉验证

- **10-fold** StratifiedKFold（之前用 5-fold，10-fold 线上 +0.002）
- **8 seeds** (2040-2047)：每个 seed 用不同的 fold 划分
- **3 bagging** (random_seed=seed×100+{0,1,2})：每 fold 训练 3 个模型取平均
- 总计: 8 × 10 × 3 = 240 个模型/臂

## 4. 融合

### 4.1 双臂融合

```
my_cb = 0.64 × rank(arm1_pooled) + 0.36 × rank(arm2_pooled)
```

权重 0.64/0.36 通过 OOF grid search 确定（arm1 更强，故权重更高）。

### 4.2 max2 跨模型融合

```
max2 = max(rank(my_cb), rank(ref))
```

`my_cb` 和 `ref` 是两个独立训练的 CatBoost 管线（Spearman 0.991）。
取 rank 最大值的直觉: 两个模型在"各自不确定"的样本上会给出较低的 rank，
取 max 能让"至少一个模型有信心"的样本排名上升。

验证: 跨 10 个随机半子集，max2 lift = +0.00176 ± 0.00057 (10/10 正向)。
机制分析: max2 使正例平均排名 +0.0158, 负例 +0.0139, 净正例优势 +0.0019。

### 4.3 byte0 + byte7 TE

id 哈希的第 0 字节 (hex chars 0-1) 和第 7 字节 (hex chars 14-15) 各有 256 个离散值。

折内 target encoding:
```
# 5-fold, seed=42
for each fold:
    rate = mean(label | byte_value) computed on training folds
    apply rate to validation fold
```

byte0+7 组合: 两者的 fold-local TE 等权平均后 rank-normalize。

最终融合权重: w_te ≈ 0.11（在 OOF 上 coarse grid 优化）。

## 5. OOF → Online Gap

| 提交 | OOF | Online | Gap |
|------|-----|--------|-----|
| W62 | 0.70159 | 0.71503 | 0.01344 |
| vz13 | 0.70050 | 0.71393 | 0.01343 |
| vz17 | 0.70170 | 0.71487 | 0.01317 |

Gap 一致地落在 0.01317-0.01344。可能原因: 测试集略"容易"于交叉验证估计
（模型最终在全量 train 上训练，比 90% 子集训练的 OOF 更强）。

vz19 预测:
- 保守 (gap=0.01317): online = 0.71672
- 均值 (gap=0.01335): online = 0.71690
