#!/usr/bin/env bash
# 一键复现 v5_honest 方案(完整,从数据重跑,~3.5 小时)
# 用法: bash reproduce.sh
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$(pwd)/src:${PYTHONPATH:-}"

echo "================================================"
echo "  复现 v5_honest: max3(mo8 + ca8 + arm_gap)"
echo "  nested target = 0.70253 (pure honest, unbiased)"
echo "  预计耗时: ~3.5 小时 (2 arms×8seeds + 1 arm×4seeds)"
echo "================================================"

# 臂1: merger_ord8 (v2 主帧 + Ordered, depth=5, 8 seeds, ~95 min)
echo ""
echo "[1/4] 训练 merger_ord8..."
for c in 0 1 2 3; do
    echo "  --- chunk $c ---"
    python3 src/v2fe_ord_chunk.py "$c"
done
python3 src/combine_chunks.py merger_ord8 v2fe_ord_c0 v2fe_ord_c1 v2fe_ord_c2 v2fe_ord_c3

# 臂2: v2_cat_alt8 (v2 alt 编码世界, depth=6, 8 seeds, ~55 min)
echo ""
echo "[2/4] 训练 v2_cat_alt8..."
for c in 0 1 2 3; do
    echo "  --- chunk $c ---"
    python3 src/v2_cat_alt_chunk.py "$c"
done
python3 src/combine_chunks.py v2_cat_alt8 v2_cat_alt_c0 v2_cat_alt_c1 v2_cat_alt_c2 v2_cat_alt_c3

# 臂3: arm_gap (B6 gap 视图, depth=6, iter=500, 4 seeds, 诚实, ~40 min)
echo ""
echo "[3/4] 训练 arm_gap (honest, 4 seeds)..."
python3 src/run_gap_arm.py

# 融合
echo ""
echo "[4/4] max3 融合 -> submission_v5_honest.csv"
python3 src/fuse_v5.py

echo ""
echo "================================================"
echo "  完成。预期 nested = 0.70253 (无偏)"
echo "  提交文件: submissions/submission_v5_honest.csv"
echo "================================================"
