"""Combine v6_b5v2 chunk npz files via RAW average (NOT rank-pool).

IMPORTANT: Unlike combine_chunks.py (which rank-pools across chunks), this
script does a plain arithmetic mean of the chunk-level pooled oof/test_pred.
The chunk-level values are already raw-pooled within each 2-seed chunk
(v6_b5v2_chunk.py accumulates raw, not rank-normalized). So the 8-seed
combination is a raw average of 4 × 2-seed raw pools.

This raw version (v6_b5v2_8raw) gives OOF 0.70060, vs the rank-pool version
(v6_b5v2_8seed) at 0.69929. The raw version is stronger and is what
submission_v6_final.csv uses.

Usage: python3 src/combine_raw.py <OUT_TAG> <chunk0> <chunk1> [...]
  e.g. python3 src/combine_raw.py v6_b5v2_8raw v6_b5v2_c0 v6_b5v2_c1 v6_b5v2_c2 v6_b5v2_c3
"""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score

ART = Path(__file__).resolve().parent.parent / "artifacts"
out_tag = sys.argv[1]
chunks = sys.argv[2:]


def main():
    oofs, tes, all_per_seed, all_seeds = [], [], [], []
    y = None
    for c in chunks:
        d = np.load(ART / f"{c}.npz", allow_pickle=True)
        oofs.append(np.asarray(d["oof"], dtype=float))
        tes.append(np.asarray(d["test_pred"], dtype=float))
        all_per_seed.extend(np.asarray(d["per_seed"]).tolist())
        all_seeds.extend(np.asarray(d["seeds"]).tolist())
        y = np.asarray(d["y"], dtype=int)
    # RAW average across chunks (NO rankdata step)
    oof = np.mean(np.vstack(oofs), axis=0)
    te = np.mean(np.vstack(tes), axis=0)
    auc = roc_auc_score(y, oof)
    print(f"[combine_raw] {out_tag}: {len(all_seeds)} seeds raw-avg OOF AUC = {auc:.6f}")
    print(f"  per-seed mean = {np.mean(all_per_seed):.6f} ± {np.std(all_per_seed):.6f}")
    print(f"  per-seed vals = {[f'{x:.5f}' for x in all_per_seed]}")
    np.savez(ART / f"{out_tag}.npz", oof=oof, test_pred=te,
             per_seed=np.array(all_per_seed), seeds=np.array(all_seeds), y=y)
    print(f"  wrote artifacts/{out_tag}.npz")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
