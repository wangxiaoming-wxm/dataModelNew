# vz19: max2 跨模型融合 + byte0/byte7 TE

保险理赔预测比赛方案。二分类，AUC 评测。

## 结果

| 指标 | 值 |
|------|-----|
| **OOF AUC** | **0.70355** |
| vs W62 OOF (0.70159) | **+0.00196** |
| vs 参考解 OOF (0.70172) | +0.00183 |
| Online 预测区间 | 0.7167 ~ 0.7170 |

## 方法概要

```
vz19 = (1 - w) × max2(my_cb, ref) + w × byte07_TE     (w ≈ 0.11)
```

三个独立组件：

### 1. 我的 CatBoost (`my_cb`)
- **arm1**: `build_main` 特征, Ordered boosting, depth=5, l2=10, rsm=1.0
- **arm2**: `build_alt` 特征, Plain boosting, depth=6, l2=6, rsm=0.3
- 融合: `0.64 × rank(arm1) + 0.36 × rank(arm2)`
- 训练: 10-fold CV × 8 seeds × 3 bagging = 240 模型/臂
- **关键发现**: rsm=0.3（30% 特征子采样）是 121 特征数据的最优正则

### 2. 参考解 CatBoost (`ref`)
- 同样的 `build_main`/`build_alt` 特征体系
- CatBoostRegressor + RMSE loss
- 5-fold CV × 5 seeds
- OOF = mean(main, alt, fuse), rank-normalized

### 3. byte0 + byte7 TE
- id 哈希的第 0 字节和第 7 字节（各 256 个离散值）
- 折内 target encoding（5-fold, seed=42），等权组合
- **关键发现**: byte7 是除 byte0 外唯一有真实信号的 id 字节
  - byte0 cross-half AUC: 0.5200 (20/20 > 0.5)
  - byte7 cross-half AUC: 0.5139 (20/20 > 0.5)
  - byte0+7 组合 TE OOF: 0.5267 >> byte0 单独 0.5192

### 为什么用 max2 而不是加权平均？

两个独立训练的 CatBoost（Spearman 0.991）在错误样本上有互补性。
取 rank 最大值能同时提升正例和负例排名，但正例提升略多，净优势 +0.0019。
跨 10 个随机半子集验证：**10/10 正向**（mean lift +0.00176）。

## 复现步骤

### 前置条件

```bash
pip install catboost scikit-learn scipy pandas numpy
```

数据文件（不在本包内）:
- `data/train.csv` (14930 行, 45 列, 含 label)
- `data/test.csv` (6398 行, 44 列)

### Step 1: 训练 arm1

```bash
cd src
python3 train_catboost.py --arm arm1 --data-dir ../data --out-dir ../checkpoints/arm1
# 耗时 ~90 分钟 (8 seeds × 10 folds × 3 bags)
```

### Step 2: 训练 arm2

```bash
python3 train_catboost.py --arm arm2 --data-dir ../data --out-dir ../checkpoints/arm2
# 耗时 ~120 分钟
```

### Step 3: 训练参考解

参考解使用相同的特征工程但不同的 seeds (2026-2030) 和 5-fold。
代码见原始仓库 `CreateDataModel/explore_best.py`。
输出: `best_oof.npy` (dict{main,alt,fuse}), `best_test.npy` (dict{main,alt,fuse})

### Step 4: 融合 + byte TE → submission

```bash
python3 build_vz19.py \
  --arm1-dir ../checkpoints/arm1 \
  --arm2-dir ../checkpoints/arm2 \
  --ref-dir ../checkpoints/ref \
  --data-dir ../data \
  --out ../submission_vz19.csv
```

### Step 5: 验证（可选）

```bash
python3 validate.py \
  --arm1-dir ../checkpoints/arm1 \
  --arm2-dir ../checkpoints/arm2 \
  --ref-dir ../checkpoints/ref \
  --data-dir ../data
```

## 文件结构

```
vz19_release/
├── README.md                ← 本文件
├── src/
│   ├── features.py          ← 特征工程 (build_main + build_alt)
│   ├── train_catboost.py    ← CatBoost 训练 (arm1/arm2)
│   ├── build_vz19.py        ← 最终融合 + byte0/7 TE
│   └── validate.py          ← 验证脚本 (byte cross-half, max2, weight)
├── docs/
│   ├── METHOD.md            ← 方法详解
│   └── EVIDENCE.md          ← 实验证据 (byte7发现, max2验证, 过拟合检验)
└── submission_vz19.csv      ← 最终提交文件
```

## 关键设计决策与证据

| 决策 | 证据 |
|------|------|
| RMSE 而非 Logloss | Logloss/CrossEntropy OOF=0.51 (近随机), RMSE=0.70 |
| rsm=0.3 for arm2 | 扫描: 0.3 > 0.5 > 0.25 > 0.4 > 1.0 |
| 10fold 而非 5fold | 线上 +0.002 (0.70878 → 0.71064) |
| max2 而非加权平均 | 跨 10 半子集 10/10 正向, +0.00176 |
| byte0+byte7 TE | 20 split cross-half 全部 > 0.5, 组合 OOF 0.5267 |
| max_ctr_complexity=1 | 提升至 2/3 会降 OOF -0.003~-0.004 (特征饱和) |

详见 `docs/EVIDENCE.md`。
