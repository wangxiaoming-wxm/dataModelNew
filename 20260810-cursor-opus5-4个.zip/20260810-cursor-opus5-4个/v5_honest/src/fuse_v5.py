"""v5_honest fusion: max(merger_ord8 + v2_cat_alt8 + arm_gap) = nested 0.70253.

This is the strongest PURE HONEST fusion. All three arms use fixed tree counts
with no early stopping, so the nested OOF is an UNBIASED estimate of
generalization.

Recipe:
  - merger_ord8: v2 main FE + Ordered boosting, depth=5, 8 seeds (honest)
  - v2_cat_alt8: v2 'alt' encoding world, depth=6, 8 seeds (honest)
  - arm_gap:     B6 gap feature view, depth=6, iter=500, 4 seeds (honest)
  - fusion: element-wise max of rank-normalized predictions
  - metric: 5-block nested OOF AUC

NOTE: arm_gap uses 4 seeds (20290-20293) while the other two use 8 — it is
slightly noisier but still contributes via low correlation with ca8 (0.95).
Expected LB ~0.7136 (using honest gap +0.0111 from v4_honest anchor).
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score

ART = Path(__file__).resolve().parent.parent / "artifacts"
SUB = Path(__file__).resolve().parent.parent / "submissions"
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
N_BLOCKS = 5


def load(name, test_key="test_pred"):
    """Load an arm's oof + test_pred, return rank-normalized in [0,1]."""
    d = np.load(ART / f"{name}.npz", allow_pickle=True)
    oof = np.asarray(d["oof"], dtype=float)
    tk = test_key if test_key in d else ("test" if "test" in d else "test_pred")
    te = np.asarray(d[tk], dtype=float)
    return (rankdata(oof) / len(oof), rankdata(te) / len(te))


def nested_auc(oof, y, n_blocks=N_BLOCKS):
    """5-block nested OOF AUC: re-rank within each block, then AUC (unbiased)."""
    n = len(y)
    out = np.zeros(n)
    for b in np.array_split(np.arange(n), n_blocks):
        out[b] = rankdata(oof[b]) / len(b)
    return roc_auc_score(y, out)


def main():
    y = pd.read_csv(DATA / "train.csv")["label"].astype(int).values
    test = pd.read_csv(DATA / "test.csv")

    mo_oof, mo_te = load("merger_ord8")
    ca_oof, ca_te = load("v2_cat_alt8")
    gap_oof, gap_te = load("arm_gap", test_key="test")  # gap arm uses 'test' key

    print(f"  [honest] merger_ord8   oof_auc={roc_auc_score(y, mo_oof):.5f}")
    print(f"  [honest] v2_cat_alt8   oof_auc={roc_auc_score(y, ca_oof):.5f}")
    print(f"  [honest] arm_gap       oof_auc={roc_auc_score(y, gap_oof):.5f}  (4 seeds)")

    # max3 fusion (element-wise max of rank-normalized predictions)
    f_oof = np.maximum.reduce([mo_oof, ca_oof, gap_oof])
    f_te = np.maximum.reduce([mo_te, ca_te, gap_te])

    nest = nested_auc(f_oof, y)
    full = roc_auc_score(y, f_oof)
    print(f"\nmax3(merger_ord8 + v2_cat_alt8 + arm_gap)")
    print(f"  nested={nest:.5f}  full={full:.5f}")
    print(f"  (nested is UNBIASED; target = 0.70253)")
    print(f"  expected LB ~0.7136 (honest gap +0.0111)")

    # write submission
    sub = pd.DataFrame({"id": test["id"], "label": f_te.clip(0.001, 0.999)})
    out = SUB / "submission_v5_honest.csv"
    sub.to_csv(out, index=False)
    assert len(sub) == 6398
    assert sub["label"].between(0, 1).all()
    print(f"\nwrote {out}  rows={len(sub)}  label_range=[{sub.label.min():.4f},{sub.label.max():.4f}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
