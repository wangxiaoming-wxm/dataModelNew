"""V6: B5 frame ENRICHED with v2's breakthrough features (cond_r, ratio).

The B5 frame is the strongest arm (ord_noxb_bag=0.70064). It uses
cond_over_days = cond/(days+1) — the REVERSED ratio. But it does NOT have:
  - cond_r = condition / per_source_median(condition)  [single-col AUC 0.567]
  - ratio = days / cond_r                                [single-col AUC 0.620]
  - ratio crosses with source/region                     [the v2 crosses]

These are the v2 workspace's breakthrough features. Adding them to B5 gives
the model access to BOTH feature worlds in a single arm — potentially pushing
the strongest arm from 0.701 to 0.703+.

Label-free: per-source median computed on train+test (transductive, no leak).

NOTE: This arm uses use_best_model=True (ES). OOF optimistic +~0.0015,
  test predictions honest. See README §"ES bias".
NOTE: sys.path now points to local src/ (inlined insurance_claim, self-contained).

Usage: python3 src/v6_b5v2_chunk.py <CHUNK_IDX>
  CHUNK 0 -> seeds 2026,2027; 1 -> 2028,2029; 2 -> 2030,2031; 3 -> 2032,2033
"""
from __future__ import annotations
import sys, warnings, time
from pathlib import Path
warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier
from insurance_claim.train_b5_focus import build_b5, enrich, prepare_for_cat
from insurance_claim.model import TARGET

DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
ART = Path(__file__).resolve().parent.parent / "artifacts"
ALL_SEEDS = (2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033)
CHUNK_SIZE = 2
CHUNK_IDX = int(sys.argv[1]) if len(sys.argv) > 1 else 0
SEEDS = ALL_SEEDS[CHUNK_IDX * CHUNK_SIZE:(CHUNK_IDX + 1) * CHUNK_SIZE]
TAG = f"v6_b5v2_c{CHUNK_IDX}"


def add_v2_features(tr_df, va_df, te_df):
    """Add v2's cond_r/ratio features ON TOP of B5's built frame.
    Per-source median computed on train+val+test (transductive, label-free).
    Quantile edges fit on train fold only (fold-local).
    """
    # First run the standard B5 builder
    tr_b5, va_b5, te_b5, cats = build_b5(tr_df, va_df, te_df)

    # Now add v2 features. Need the raw enrich'd data for source/condition/days.
    tr_en = enrich(tr_df)
    va_en = enrich(va_df)
    te_en = enrich(te_df)
    all_en = pd.concat([tr_en, va_en, te_en], ignore_index=True)

    # per-source condition median (transductive, label-free)
    scale = all_en.groupby("source")["condition"].transform("median")
    cond = pd.to_numeric(all_en["condition"], errors="coerce")
    days = pd.to_numeric(all_en["days"], errors="coerce")
    cond_r = (cond / scale).fillna(1.0)
    ratio = days / cond_r.clip(lower=1e-9)

    # v2 numerics
    n_tr, n_va = len(tr_en), len(va_en)
    for df_target, start in [(tr_b5, 0), (va_b5, n_tr), (te_b5, n_tr + n_va)]:
        sl = slice(start, start + len(df_target))
        df_target["cond_r"] = cond_r.iloc[sl].values
        df_target["ratio"] = ratio.iloc[sl].values
        df_target["log_cond_r"] = np.log(cond_r.iloc[sl].clip(lower=1e-9).values)
        df_target["log_ratio"] = np.log(ratio.iloc[sl].clip(lower=1e-9).values)
        df_target["ratio_p75"] = (days.iloc[sl] / np.power(cond_r.iloc[sl].clip(lower=1e-9).values, 0.75)).values

    # v2 categorical crosses: ratio quantiles × source/region
    # Fit edges on train fold only (fold-local)
    tr_ratio = ratio.iloc[:n_tr].values
    for nb in (5, 10):
        qs = np.linspace(0, 1, nb + 1)[1:-1]
        edges = np.quantile(tr_ratio[np.isfinite(tr_ratio)], qs) if np.isfinite(tr_ratio).any() else np.array([])
        for df_target, start, raw_src in [
            (tr_b5, 0, tr_en["source"].astype(str).values),
            (va_b5, n_tr, va_en["source"].astype(str).values),
            (te_b5, n_tr + n_va, te_en["source"].astype(str).values),
        ]:
            sl = slice(start, start + len(df_target))
            r_vals = ratio.iloc[sl].values
            r_bin = np.digitize(np.nan_to_num(r_vals, nan=-1), edges).astype(str)
            df_target[f"ratio_q{nb}"] = r_bin
            df_target[f"ratio_q{nb}_src"] = np.char.add(r_bin, np.char.add("|", raw_src.astype(str)))
            cats.append(f"ratio_q{nb}")
            cats.append(f"ratio_q{nb}_src")

    # Dedupe cats
    cats = list(dict.fromkeys(cats))
    return tr_b5, va_b5, te_b5, cats


def main():
    train = pd.read_csv(DATA / "train.csv")
    test = pd.read_csv(DATA / "test.csv")
    y = train[TARGET].astype(int)

    # B5 config (matching ord_noxb_bag: depth7, Ordered, iter1200, ES)
    from insurance_claim.train_b5_focus import CAT_PARAMS
    p = {k: v for k, v in CAT_PARAMS.items() if k != "random_seed"}
    p.pop("l2_leaf_reg", None)
    p.update(depth=7, iterations=1200, boosting_type="Ordered")

    features = train.drop(columns=[TARGET])
    pooled_oof = np.zeros(len(train))
    pooled_te = np.zeros(len(test))
    per_seed = []
    t_all = time.time()
    for seed in SEEDS:
        oof_s = np.zeros(len(train))
        te_s = np.zeros(len(test))
        t0 = time.time()
        for fold, (tri, vai) in enumerate(
            StratifiedKFold(5, shuffle=True, random_state=seed).split(features, y)
        ):
            Xtr = features.iloc[tri].reset_index(drop=True)
            Xva = features.iloc[vai].reset_index(drop=True)
            Xte = test.copy()
            ytr = y.iloc[tri].reset_index(drop=True)
            yva = y.iloc[vai].reset_index(drop=True)
            tr_df, va_df, te_df, cats = add_v2_features(Xtr, Xva, Xte)
            m = CatBoostClassifier(**dict(p, random_seed=seed + fold))
            m.fit(tr_df, ytr, eval_set=(va_df, yva), cat_features=cats,
                  use_best_model=True, verbose=False)
            oof_s[vai] = m.predict_proba(va_df)[:, 1]
            te_s += m.predict_proba(te_df)[:, 1] / 5
        a = roc_auc_score(y, oof_s)
        per_seed.append(a)
        print(f"[{TAG}] seed {seed}: OOF={a:.6f} ({time.time()-t0:.0f}s, {len(cats)} cats, {tr_df.shape[1]} feats)", flush=True)
        pooled_oof += oof_s
        pooled_te += te_s
    pooled_oof /= len(SEEDS)
    pooled_te /= len(SEEDS)
    pool_auc = roc_auc_score(y, pooled_oof)
    print(f"\n[{TAG}] {len(SEEDS)}-seed pooled OOF = {pool_auc:.6f}  "
          f"(per-seed {np.mean(per_seed):.6f} ± {np.std(per_seed):.6f})  "
          f"total {time.time()-t_all:.0f}s", flush=True)
    np.savez(ART / f"{TAG}.npz", oof=pooled_oof, test_pred=pooled_te,
             per_seed=np.array(per_seed), seeds=np.array(SEEDS), y=y.to_numpy())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
