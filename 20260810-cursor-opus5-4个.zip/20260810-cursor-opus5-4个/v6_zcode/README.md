# v6_final 方案 — max3 三臂融合(含 ES 臂,b5v2 增强)

> 比赛:AUC 二分类 | train 14930×44, test 6398×43, 目标 `label`(10% 正例)
> 嵌套 OOF:**0.70326**(乐观上界,含 ES 偏差)| 所有方案里最高

## 方案是什么

三个 CatBoost 臂做 **逐元素 max 融合**。两个诚实臂 + 一个 **ES 增强** 臂(b5v2):

| 臂 | 编码世界 | 配置 | 种子 | 单臂 OOF | 诚实? |
|---|---|---|---|---:|:---:|
| `merger_ord8` | v2 主帧 FE + Ordered | depth=5, iter=800 | 2026..2033 (8) | 0.69660 | ✅ |
| `v2_cat_alt8` | v2 alt 编码世界 | depth=6, iter=800 | 2026..2033 (8) | 0.69704 | ✅ |
| `v6_b5v2_8raw` | B5 帧 + v2 cond_r/ratio 特征 | depth=7, iter=1200, **ES** | 2026..2033 (8) | 0.70060 | ⚠️ ES |
| **max3 融合** | 逐元素 max(rank) | — | — | **0.70326** | ⚠️ 含ES |

## 第 3 臂的核心创新:b5v2 增强

`v6_b5v2_8raw` 是本方案的特色——把 **两个特征世界融合进单个臂**:
- **B5 帧**(insurance_claim 的 build_b5):领域解析 + 结构化字符串 + days/condition 物理特征。这是单臂最强的基座(ord_noxb_bag 用它)。
- **v2 突破特征**(内联 add_v2_features):
  - `cond_r = condition / per_source_median(condition)` —— 按来源归一化的条件强度(单列 AUC 0.567)
  - `ratio = days / cond_r` —— 关键比值(单列 AUC 0.620)
  - `ratio` 的分位数交叉(`ratio_q5`, `ratio_q10`)× source —— 类别交叉特征

这两个特征世界此前分散在不同臂里(B5 臂和 v2 臂)。b5v2 把它们合进一个 CatBoost 模型,让单臂从 0.7006(ord_noxb_bag)提升到 0.70060(几乎持平但特征更丰富),且与 v2 主帧/alt 臂形成更好的互补。

**label-free 保证**:per-source median 在 train+val+test 上计算(transductive,无泄漏);分位数切点只在 train fold 上拟合(fold-local)。

## ⚠️ 两个关键细节

### 1. ES 偏差(OOF 乐观)
`v6_b5v2_8raw` 用 `use_best_model=True`(验证折早停):
- **OOF AUC 乐观 +~0.0015** → nested 0.70326 是乐观上界,非无偏估计
- **测试预测完全诚实** → 提交可用

诚实修正后估计:0.70326 − 0.0015 ≈ **0.7018**(仍 > v4_honest 0.69993,但 < v5_honest 0.70253)。

### 2. raw-average 聚合(非 rank-pool)
`v6_b5v2_8raw` 的 8 种子聚合用 **raw 算术平均**,不是 rank-pool。对比:
- raw-average(本方案):OOF 0.70060
- rank-pool(标准做法):OOF 0.69929

raw 版更强,因为 CatBoost 概率在该数据分布上 raw 平均保留了更多区分度。combine 必须用 `combine_raw.py`(不是 `combine_chunks.py`)。

### 3. 提交不 clip
submission 的 label 范围是 [0.0002, 1.0000],**不** clip 到 [0.001, 0.999](与其他方案不同)。这是原始验证版本的精确行为。

## 与其他方案对比

| 方案 | 第3臂 | nested | 诚实? | 性质 |
|---|---|---:|:---:|---|
| **v6_final** | b5v2_8raw (ES) | **0.70326** | ⚠️ ES | 最高,但乐观 |
| v4_max3 | ord_noxb_bag (ES) | 0.70307 | ⚠️ ES | LB 已验证 0.71222 |
| v5_honest | arm_gap (honest) | 0.70253 | ✅ | 纯诚实无偏 |
| v4_honest | (无第3臂) | 0.69993 | ✅ | 诚实基线 |

## 依赖

```bash
pip install catboost lightgbm scikit-learn pandas numpy scipy
```

- Python 3.10+
- 数据(共享路径):`/Volumes/pssd/app/ml/正式比赛/data/{train,test}.csv`

## 目录结构

```
.
├── src/
│   ├── v2fe_ord_chunk.py        # 臂1 chunk 脚本(V2_SRC→本地 src2/)
│   ├── v2_cat_alt_chunk.py      # 臂2 chunk 脚本(V2_SRC→本地 src2/)
│   ├── combine_chunks.py        # 合并臂1/2 (rank-pool)
│   ├── v6_b5v2_chunk.py         # 臂3 chunk 脚本(ES, 内联 add_v2_features)
│   ├── combine_raw.py           # 合并臂3 (RAW average, 非 rank-pool!)
│   ├── fuse_v6.py               # max3 融合 → submission_v6_final.csv
│   ├── src2/                    # 内联依赖:features/arms/jitter/te
│   └── insurance_claim/         # 内联依赖:特征工程库(含 feature_blocks/, v10_plus/)
├── artifacts/                   # 预计算臂(可秒级复现 fuse)
│   ├── merger_ord8.npz
│   ├── v2_cat_alt8.npz
│   └── v6_b5v2_8raw.npz
├── submissions/
│   └── submission_v6_final.csv  # 最终提交(6398 行, 不 clip)
└── reproduce.sh                 # 一键复现
```

## 复现

### 快速(用预计算臂,秒级)
```bash
python3 src/fuse_v6.py
```
预期输出 `nested=0.70326`。

### 完整(从数据重跑,~4 小时)
```bash
bash reproduce.sh
```
