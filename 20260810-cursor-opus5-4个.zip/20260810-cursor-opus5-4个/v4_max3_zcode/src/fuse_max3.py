"""v4_max3 fusion: max(merger_ord8 + v2_cat_alt8 + ord_noxb_bag) = nested 0.70307.

This is the strongest fusion by nested OOF. The third arm (ord_noxb_bag) uses
early stopping (use_best_model=True), so:
  - Its OOF AUC carries +~0.0015 optimism (ES peeks at val fold).
  - Its TEST prediction is honest (ES never sees test).
The fusion's nested OOF (0.70307) is therefore an OPTIMISTIC upper bound on
generalization, but the submission's test predictions are valid.

Real LB (verified): 0.71222.

Recipe:
  - merger_ord8: v2 main FE + Ordered boosting, depth=5, 8 seeds (honest)
  - v2_cat_alt8: v2 'alt' encoding world, depth=6, 8 seeds (honest)
  - ord_noxb_bag: B5 no-xbin + Ordered, depth=7, 8 seeds (ES, OOF optimistic)
  - fusion: element-wise max of rank-normalized predictions
  - metric: 5-block nested OOF AUC
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score

ART = Path(__file__).resolve().parent.parent / "artifacts"
SUB = Path(__file__).resolve().parent.parent / "submissions"
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
N_BLOCKS = 5


def load(name, test_key="test_pred"):
    """Load an arm's oof + test_pred, return rank-normalized in [0,1]."""
    d = np.load(ART / f"{name}.npz", allow_pickle=True)
    oof = np.asarray(d["oof"], dtype=float)
    te = np.asarray(d[test_key], dtype=float)
    return (rankdata(oof) / len(oof), rankdata(te) / len(te))


def nested_auc(oof, y, n_blocks=N_BLOCKS):
    """5-block nested OOF AUC: re-rank within each block, then AUC (conservative)."""
    n = len(y)
    out = np.zeros(n)
    for b in np.array_split(np.arange(n), n_blocks):
        out[b] = rankdata(oof[b]) / len(b)
    return roc_auc_score(y, out)


def main():
    y = pd.read_csv(DATA / "train.csv")["label"].astype(int).values
    test = pd.read_csv(DATA / "test.csv")

    mo_oof, mo_te = load("merger_ord8")
    ca_oof, ca_te = load("v2_cat_alt8")
    ord_oof, ord_te = load("ord_noxb_bag")  # ES arm: OOF optimistic, test honest

    print(f"  [honest] merger_ord8   oof_auc={roc_auc_score(y, mo_oof):.5f}")
    print(f"  [honest] v2_cat_alt8   oof_auc={roc_auc_score(y, ca_oof):.5f}")
    print(f"  [ES*]    ord_noxb_bag  oof_auc={roc_auc_score(y, ord_oof):.5f}  (optimistic +~0.0015)")

    # max3 fusion
    f_oof = np.maximum.reduce([mo_oof, ca_oof, ord_oof])
    f_te = np.maximum.reduce([mo_te, ca_te, ord_te])

    nest = nested_auc(f_oof, y)
    full = roc_auc_score(y, f_oof)
    print(f"\nmax3(merger_ord8 + v2_cat_alt8 + ord_noxb_bag)")
    print(f"  nested={nest:.5f}  full={full:.5f}")
    print(f"  (nested is OPTIMISTIC due to ES arm; target = 0.70307)")
    print(f"  verified LB = 0.71222")

    # write submission
    sub = pd.DataFrame({"id": test["id"], "label": f_te.clip(0.001, 0.999)})
    out = SUB / "submission_v4_max3.csv"
    sub.to_csv(out, index=False)
    assert len(sub) == 6398
    assert sub["label"].between(0, 1).all()
    print(f"\nwrote {out}  rows={len(sub)}  label_range=[{sub.label.min():.4f},{sub.label.max():.4f}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
