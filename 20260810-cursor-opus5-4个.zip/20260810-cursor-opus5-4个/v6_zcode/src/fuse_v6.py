"""v6_final fusion: max(merger_ord8 + v2_cat_alt8 + v6_b5v2_8raw) = nested 0.70326.

This is the strongest fusion by nested OOF across all explored recipes.

Recipe:
  - merger_ord8:    v2 main FE + Ordered, depth=5, 8 seeds (honest)
  - v2_cat_alt8:    v2 'alt' encoding world, depth=6, 8 seeds (honest)
  - v6_b5v2_8raw:   B5 frame + v2 cond_r/ratio features, depth=7, 8 seeds (ES,
                    raw-avg pooled, NOT rank-pool)
  - fusion: element-wise max of rank-normalized predictions
  - metric: 5-block nested OOF AUC

NOTE: The 3rd arm (v6_b5v2_8raw) uses use_best_model=True (ES), so the nested
  OOF is OPTIMISTIC (+~0.0015). Test predictions are honest.
NOTE: The submission is NOT clipped to [0.001, 0.999] (unlike other recipes).
  Range is [~0.0002, ~1.0]. This matches the verified submission_v6_final.csv.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score

ART = Path(__file__).resolve().parent.parent / "artifacts"
SUB = Path(__file__).resolve().parent.parent / "submissions"
DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
N_BLOCKS = 5


def load(name):
    """Load an arm's oof + test_pred, return rank-normalized in [0,1]."""
    d = np.load(ART / f"{name}.npz", allow_pickle=True)
    oof = np.asarray(d["oof"], dtype=float)
    te = np.asarray(d["test_pred"], dtype=float)
    return (rankdata(oof) / len(oof), rankdata(te) / len(te))


def nested_auc(oof, y, n_blocks=N_BLOCKS):
    """5-block nested OOF AUC: re-rank within each block, then AUC."""
    n = len(y)
    out = np.zeros(n)
    for b in np.array_split(np.arange(n), n_blocks):
        out[b] = rankdata(oof[b]) / len(b)
    return roc_auc_score(y, out)


def main():
    y = pd.read_csv(DATA / "train.csv")["label"].astype(int).values
    test = pd.read_csv(DATA / "test.csv")

    mo_oof, mo_te = load("merger_ord8")
    ca_oof, ca_te = load("v2_cat_alt8")
    b5_oof, b5_te = load("v6_b5v2_8raw")  # ES arm: OOF optimistic, test honest

    print(f"  [honest] merger_ord8   oof_auc={roc_auc_score(y, mo_oof):.5f}")
    print(f"  [honest] v2_cat_alt8   oof_auc={roc_auc_score(y, ca_oof):.5f}")
    print(f"  [ES*]    v6_b5v2_8raw  oof_auc={roc_auc_score(y, b5_oof):.5f}  (optimistic +~0.0015)")

    # max3 fusion
    f_oof = np.maximum.reduce([mo_oof, ca_oof, b5_oof])
    f_te = np.maximum.reduce([mo_te, ca_te, b5_te])

    nest = nested_auc(f_oof, y)
    full = roc_auc_score(y, f_oof)
    print(f"\nmax3(merger_ord8 + v2_cat_alt8 + v6_b5v2_8raw)")
    print(f"  nested={nest:.5f}  full={full:.5f}")
    print(f"  (nested is OPTIMISTIC due to ES arm; target = 0.70326)")

    # write submission — NO clip (matches verified submission_v6_final.csv)
    sub = pd.DataFrame({"id": test["id"], "label": f_te})
    out = SUB / "submission_v6_final.csv"
    sub.to_csv(out, index=False)
    assert len(sub) == 6398
    assert sub["label"].between(0, 1).all()
    print(f"\nwrote {out}  rows={len(sub)}  label_range=[{sub.label.min():.4f},{sub.label.max():.4f}]  (NOT clipped)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
