# v4_max3 方案 — max3 三臂融合(含 ES 臂)

> 比赛:AUC 二分类 | train 14930×44, test 6398×43, 目标 `label`(10% 正例)
> 嵌套 OOF:**0.70307**(乐观上界,含 ES 偏差)| **公开榜实测:0.71222**

## 方案是什么

三个 CatBoost 臂做 **逐元素 max 融合**。两个诚实臂 + 一个 ES(早停)臂:

| 臂 | 编码世界 | 配置 | 种子 | 单臂 OOF | 诚实? |
|---|---|---|---|---:|:---:|
| `merger_ord8` | v2 主帧 FE + Ordered | depth=5, iter=800 | 2026..2033 (8) | 0.69660 | ✅ |
| `v2_cat_alt8` | v2 alt 编码世界 | depth=6, iter=800 | 2026..2033 (8) | 0.69704 | ✅ |
| `ord_noxb_bag` | B5 no-xbin + Ordered | depth=7, iter=1200, **ES** | 2026..2033 (8) | 0.70064 | ⚠️ ES |
| **max3 融合** | 逐元素 max(rank) | — | — | **0.70307** | ⚠️ 含ES |

## ⚠️ ES 偏差说明(重要)

`ord_noxb_bag` 用了 `use_best_model=True`(在验证折上早停选迭代数)。这造成:

- **OOF AUC 乐观 +~0.0015**:早停偷看了验证折,所以 OOF 不是无偏泛化估计。融合后的 nested 0.70307 因此是**乐观上界**。
- **测试预测完全诚实**:早停只在训练折的验证子集选迭代,**从不接触测试集**。部署时用该迭代模型预测测试,输出无偏。

所以 `submission_v4_max3.csv` 的测试预测可直接提交,但其 nested OOF (0.70307) 不能当作无偏泛化估计。诚实的无偏估计见 v4_honest 包(0.69993)。

**实测验证:nested 0.70307 → 公开榜 0.71222,gap +0.00915。**

## 依赖

```bash
pip install catboost lightgbm scikit-learn pandas numpy scipy
```

- Python 3.10+
- 数据(共享路径,本仓库不含):
  - `/Volumes/pssd/app/ml/正式比赛/data/train.csv`
  - `/Volumes/pssd/app/ml/正式比赛/data/test.csv`

> 如数据在别处,改 `src/*.py` 顶部的 `DATA = Path(...)`。

## 目录结构

```
.
├── src/
│   ├── v2fe_ord_chunk.py        # 臂1 chunk 脚本(V2_SRC→本地 src2/)
│   ├── v2_cat_alt_chunk.py      # 臂2 chunk 脚本(V2_SRC→本地 src2/)
│   ├── combine_chunks.py        # 合并 4 chunk → 8 种子臂
│   ├── ord_noxb_bag.py          # 臂3 ES 臂(insurance_claim, use_best_model)
│   ├── fuse_max3.py             # max3 融合 → submission_v4_max3.csv
│   ├── src2/                    # 内联依赖:features/arms/jitter/te
│   └── insurance_claim/         # 内联依赖:特征工程库(含 feature_blocks/, v10_plus/)
├── artifacts/                   # 预计算臂(可秒级复现 fuse)
│   ├── merger_ord8.npz
│   ├── v2_cat_alt8.npz
│   └── ord_noxb_bag.npz
├── submissions/
│   └── submission_v4_max3.csv   # 最终提交(6398 行)
└── reproduce.sh                 # 一键复现
```

## 复现

### 快速(用预计算臂,秒级)
```bash
python3 src/fuse_max3.py
```
预期输出 `nested=0.70307`。

### 完整(从数据重跑,~4 小时)
```bash
bash reproduce.sh
```

## 三个臂的逻辑

1. **merger_ord8**(诚实):v2 主帧特征工程(条件分位数、jitter 多视图)+ Ordered boosting。Ordered 在小数据上防过拟合。
2. **v2_cat_alt8**(诚实):v2 的"alt 编码世界"——用 `rate=days×(1-rank_pct)` 重新表达条件特征,与主帧解耦。
3. **ord_noxb_bag**(ES):B5 基础特征去掉 x0:x18 分箱 + Ordered boosting。它的误差与前两臂正交(corr 0.87),是真正的第 3 正交臂。用 ES 让单臂更强(0.7006 > 诚实版 0.6934),代价是 OOF 乐观。

## 为什么用 max 而非 mean

max 融合对"哪些行被顶到高位"敏感。三臂中 ord_noxb_bag 够强(0.7006),能稳定贡献;mean 会因为相关性高(0.95+)而被拖平,max 更适合。
