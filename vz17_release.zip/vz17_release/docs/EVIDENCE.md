# vz17 实验证据

所有结论均有对应实验。下面列出关键证据与数字。

## 1. RMSE 而非分类 loss

| loss | OOF AUC |
|------|---------|
| RMSE（回归） | **~0.70** |
| Logloss（分类） | ~0.51 |
| CrossEntropy（分类） | ~0.51 |

分类 loss 在此数据上接近随机。同样现象在 lightgbm / xgboost / mlp 上都出现。
结论：标签来自连续理赔额二值化，回归 loss 契合信号结构。

## 2. rsm 扫描（arm2 关键正则）

arm2（build_alt，~100 特征，Plain boosting）单 fold 扫描 rsm：

| rsm | 单 fold AUC |
|-----|------------|
| 0.25 | 0.7040 |
| **0.30** | **0.7065** ← 最优 |
| 0.40 | 0.7034 |
| 0.50 | 0.7043 |
| 1.0（默认） | 基线 |

每 seed 实测 +0.002。arm1（Ordered boosting）下 rsm=0.3 提升 < 0.0004，故 arm1 保持 rsm=1.0。

## 3. 10fold vs 5fold

10fold 比 5fold 在线上实测 +0.002（前期版本对比，非本包内部）。
本包两臂均用 10fold。

## 4. byte0 信号

byte0 = id 哈希前两字符转 int（0-255），共 256 个离散值。

### cross-half 稳定性（train 内）
把 train 随机切两半，A 半算 `mean(label|byte0)` 编码 B 半，反之亦然。
20 个随机半子集（seed 1000-1019）实跑结果：
- 19/20 次 AUC > 0.5（1 次跌到 0.49935，属噪声）
- mean = 0.52101，std = 0.00932
- 区间 [0.49935, 0.53396]

可由 `python3 validate.py --data-dir ../data` 复现。
结论：byte0 是 train 内**弱但基本稳定**的真实信号（不是干净的 20/20，有个别 split 在噪声边缘）。

### 折内 TE OOF
5-fold（seed=42）折内 target encoding，实测 OOF AUC = 0.51919。
作为微调分量加入双臂融合：OOF 0.70105 → 0.70170（+0.00065）。

> 注意：cross-half 是 train 内部检验，证明 byte0 "不是单次随机偶然"，
> **不等于** train→test 迁移证明。byte0 在 test 上是否完全迁移，
> 硬证据只有"实际提交 0.71487"这一事实。

## 5. 双臂融合权重

rank-weighted 融合 `w·rank(arm1) + (1-w)·rank(arm2)`，OOF 扫描 0.30-0.80：
- 最优 w = 0.64
- arm1 pooled OOF = 0.69952
- arm2 pooled OOF = 0.69680
- 融合 OOF = 0.70105（高于任一单臂）

两臂 Pearson 相关 ≈ 0.94，不完美相关 → 融合有增益。

## 6. OOF→online gap 校准

实际提交过的数据点（OOF / 线上 / gap）：

| 方案 | OOF | 线上 | gap |
|------|-----|------|-----|
| vz17（本包） | 0.70170 | **0.71487** | 0.01317 |

gap 不是常数（比赛其他方案观测到 0.01317-0.01344 区间），与方法组件有关。
vz17 的 gap 0.01317 偏小区间下沿，对应 byte0 7% 混入在 test 上的轻微稀释。

## 7. 复现核验

复现者跑完 Step 1-3 后，应得到：
- `build_vz17.py` 打印的 arm1/arm2/融合/byte0/final OOF 与本文件数字一致（±1e-4，浮点/线程相关）
- 生成的 `submission_vz17.csv` 与包内 `submission_vz17.csv` 内容一致
  （SHA256: `2620a16a0c47116410b85238e0b35a418edfc49b19e19042ca1ec0e7eb413255`）

如 OOF 偏差较大，最可能是 catboost / numpy 版本差异或线程数导致的浮点差异。
