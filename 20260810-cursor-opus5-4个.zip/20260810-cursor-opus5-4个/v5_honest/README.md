# v5_honest 方案 — max3 纯诚实三臂融合

> 比赛:AUC 二分类 | train 14930×44, test 6398×43, 目标 `label`(10% 正例)
> 嵌套 OOF:**0.70253**(纯诚实、无偏)| 预期公开榜:~0.7136

## 方案是什么

三个 **纯诚实 CatBoost 臂**(固定树数、无早停、label-free 特征工程)做 **逐元素 max 融合**:

| 臂 | 编码世界 | 配置 | 种子 | 单臂 OOF |
|---|---|---|---|---:|
| `merger_ord8` | v2 主帧 FE + Ordered | depth=5, iter=800 | 2026..2033 (8) | 0.69660 |
| `v2_cat_alt8` | v2 alt 编码世界 | depth=6, iter=800 | 2026..2033 (8) | 0.69704 |
| `arm_gap` | B6 gap 特征视图 | depth=6, iter=500 | 20290..20293 (4) | 0.69636 |
| **max3 融合** | 逐元素 max(rank) | — | — | **0.70253** |

## 为什么是"纯诚实"

三个臂全部:
- **固定树数,无 `use_best_model`**(无早停 → OOF 无乐观偏差)
- **特征工程 label-free**(分位数切点、gap 交叉特征都在 train+test 上拟合,fold-local)
- nested OOF 0.70253 是 **无偏泛化估计**,不是乐观上界

对比 v4_max3(nested 0.70307):那个含 ES 臂,OOF 乐观 +~0.0015,诚实修正后约 0.7016。**本方案诚实修正后更高**。

## gap 臂的作用(第 3 正交臂)

`arm_gap` 来自 `insurance_claim/train_b6.build_gap`:B5 基础特征 + fold-local 挖掘的 gap 类别交叉。它是**独立编写的同一份数据的另一种表达**,与前两臂解耦:
- gap 与 ca8 的相关性 **0.953**(所有臂对里最低),是真正的多样性来源
- 单臂 0.69636,加入 max3 后贡献 **+0.00260**(0.69993 → 0.70253)

## ⚠️ 已知局限:gap 臂只有 4 种子

`arm_gap` 用 4 个种子(20290-20293),而前两臂用 8 个种子。这意味着 gap 部分没有充分种子平均降噪,真实泛化可能比 CV 显示的低 ~0.0005-0.001。如要更稳,可把 gap 扩到 8 种子。

## LB 预测依据

用已验证的诚实锚点校准(v4_honest:nested 0.69993 → LB 0.71104,gap +0.01111):
- v5_honest:nested 0.70253 + 0.01111 ≈ **LB 0.7136**
- vs v4_max3 实测 LB 0.71222:预期 +0.0014(但 gap 单种子不确定性使这是 ~50/50)

## 依赖

```bash
pip install catboost lightgbm scikit-learn pandas numpy scipy
```

- Python 3.10+
- 数据(共享路径):`/Volumes/pssd/app/ml/正式比赛/data/{train,test}.csv`

## 目录结构

```
.
├── src/
│   ├── v2fe_ord_chunk.py        # 臂1 chunk 脚本(V2_SRC→本地 src2/)
│   ├── v2_cat_alt_chunk.py      # 臂2 chunk 脚本(V2_SRC→本地 src2/)
│   ├── combine_chunks.py        # 合并 4 chunk → 8 种子臂
│   ├── run_gap_arm.py           # 臂3 gap 臂(insurance_claim, 4 seeds, 诚实)
│   ├── fuse_v5.py               # max3 融合 → submission_v5_honest.csv
│   ├── src2/                    # 内联依赖:features/arms/jitter/te
│   └── insurance_claim/         # 内联依赖:特征工程库(含 feature_blocks/, v10_plus/)
├── artifacts/                   # 预计算臂(可秒级复现 fuse)
│   ├── merger_ord8.npz
│   ├── v2_cat_alt8.npz
│   └── arm_gap.npz              # 注意:键名是 test(非 test_pred)
├── submissions/
│   └── submission_v5_honest.csv # 最终提交(6398 行)
└── reproduce.sh                 # 一键复现
```

## 复现

### 快速(用预计算臂,秒级)
```bash
python3 src/fuse_v5.py
```
预期输出 `nested=0.70253`。

### 完整(从数据重跑,~3.5 小时)
```bash
bash reproduce.sh
```

## 三个臂的逻辑

1. **merger_ord8**(诚实):v2 主帧 FE(条件分位数、jitter 多视图)+ Ordered boosting。
2. **v2_cat_alt8**(诚实):v2 的"alt 编码世界"——`rate=days×(1-rank_pct)` 重新表达条件特征。
3. **arm_gap**(诚实):B6 gap 视图——B5 特征 + fold-local 挖掘的 gap 类别交叉,独立编码 → 低相关 → 多样性。
