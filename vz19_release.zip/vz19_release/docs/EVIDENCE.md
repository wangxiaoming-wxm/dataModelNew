# 实验证据

## 1. byte7 发现与验证

### 1.1 发现过程

id 为 16 字符 hex (64 bit)。将其拆为 8 个字节 (每字节 0-255)，逐一检验信号。

**Cross-half AUC**: 在一半 train 上计算 byte→label_rate，应用到另一半，测 AUC。
两半完全不共享 label，是诚实的信号检验。

### 1.2 结果 (20 个随机 split)

| 字节 | cross-half AUC (mean) | std | >0.5 的次数 |
|------|----------------------|-----|------------|
| **byte0** | **0.52001** | 0.00688 | **20/20** |
| **byte7** | **0.51387** | 0.00922 | **20/20** |
| byte6 | 0.50653 | 0.00456 | 弱 |
| byte3 | 0.50403 | 0.00673 | 噪声 |
| byte2 | 0.50375 | 0.00276 | 噪声 |
| byte1 | 0.49834 | 0.00717 | 噪声 |
| byte5 | 0.49517 | 0.00560 | 噪声 |
| byte4 | 0.48464 | 0.00516 | 反信号 |

**只有 byte0 和 byte7 有真实信号。**

### 1.3 组合效果

| 组合 | fold-local TE OOF AUC |
|------|----------------------|
| byte0 单独 | 0.51919 |
| byte7 单独 | 0.51874 |
| **byte0+byte7 (等权)** | **0.52672** |
| byte0+7+6 | 0.52602 (加 byte6 反而降) |
| byte0+7+6+3 | 0.51818 (继续降) |

byte0+byte7 是最优组合。加入更多字节会引入噪声，拉低效果。

### 1.4 在 max2+TE 融合中的贡献

| 方案 | OOF | vs max2 alone |
|------|-----|--------------|
| max2 alone | 0.70272 | — |
| max2 + byte0 (w=0.070) | 0.70320 | +0.00048 |
| max2 + byte7 (w=0.025) | 0.70291 | +0.00019 |
| **max2 + byte0+7 (w=0.110)** | **0.70355** | **+0.00082** |

### 1.5 5-fold-seed 稳健性

byte0+7 的 fold-local TE 用不同的 fold seed 计算，lift 全部正向:

| fold seed | byte0+7 TE OOF | max2+byte0+7 OOF | lift |
|-----------|---------------|-----------------|------|
| 42 | 0.52672 | 0.70355 | +0.00082 |
| 0 | 0.52062 | 0.70317 | +0.00045 |
| 7 | 0.52954 | 0.70395 | +0.00122 |
| 123 | 0.52598 | 0.70347 | +0.00075 |
| 999 | 0.52719 | 0.70361 | +0.00089 |

**5/5 全部正向，mean lift +0.00083。**

### 1.6 跨半迁移检验

在随机半 A 上优化 w_te，固定 w 应用到半 B:

| 方向 | 最优 w (on A) | B 上 lift |
|------|-------------|----------|
| A→B | 0.132 | +0.00014 |
| B→A | 0.064 | +0.00098 |

**两个方向都正向。** 均值 +0.00056，确认 lift 不是 fold-seed 巧合。

---

## 2. max2 跨模型融合验证

### 2.1 跨 10 个随机半子集

在 14930 行 train 上，随机抽取 7465 行，比较 max2 vs 更好的单模型:

```
max2 lift: 10/10 正向
mean = +0.00176, std = 0.00057
range = [+0.0008, +0.0028]
```

### 2.2 机制分析

max2 对排名的影响:
- 正例平均排名提升: +0.0158
- 负例平均排名提升: +0.0139
- **净正例优势: +0.0019**（正例被提升得更多）

这解释了为什么 max2 比 max(my_auc, ref_auc) 更好: 虽然两个模型的 AUC 接近，
但它们在个体样本上的排名有差异，取 max 让正例获益更多。

### 2.3 vs 其他融合方式

| 方法 | OOF |
|------|-----|
| **max2** | **0.70272** |
| 加权 0.5/0.5 | 0.70105 |
| 加权 0.64/0.36 | 0.70105 |
| max3(cb, ref_main, ref_alt) | 0.70279 (+0.00007, 噪声级) |
| LogReg meta-model | 0.70109 |
| Ridge meta-model | 0.70100 |
| CatBoost(d3) meta-model | 0.69823 |

**max2 严格优于所有其他融合方式。** Stacking/meta-model 无法超越 max2，
因为两个模型 Spearman 0.991，多样性不足以让 meta-model 学到有用的非线性组合。

---

## 3. 证伪的路线（不走弯路）

### 3.1 分类 loss 全部失败

| Loss | OOF AUC | 状态 |
|------|---------|------|
| RMSE (回归) | 0.677 | ✅ 唯一有效 |
| Logloss | 0.511 | ❌ 近随机 |
| CrossEntropy | 0.511 | ❌ |
| YetiRank | 不支持 | ❌ |
| PairLogit | pair 太多 | ❌ |

原因: 81 个类别列需要 CatBoost 原生 CTR，CTR 在分类 loss 下不稳定。

### 3.2 CTR 调优全部伤害

| 改动 | Δ OOF |
|------|-------|
| max_ctr_complexity=2 | -0.003 |
| max_ctr_complexity=3 | -0.004 |
| CtrBorderCount=32 | -0.004 |
| Prior=0.1 | -0.005 |

模型已特征饱和（121 特征），增加 CTR 复杂度引入噪声。

### 3.3 Stacking 证伪

用 5 个模型 OOF (arm1, arm2, ref_main, ref_alt, ref_fuse) 作为 meta-features:

| Meta-model | OOF |
|------------|-----|
| max2 (基线) | 0.70272 |
| Logistic Regression | 0.70109 |
| Ridge | 0.70100 |
| CatBoost depth=3 | 0.69823 |
| CatBoost depth=4 | 0.69822 |

**所有 meta-model 都不如 max2。** 模型间相关度太高 (0.94-0.99)，meta-model 无法利用。

### 3.4 对抗验证: 无分布漂移

训练 CatBoost 区分 train vs test: AUC = 0.50246 (≈ 随机)。
train/test 分布一致，密度比加权等路线无效。

### 3.5 多样化模型 (lgb/xgb/mlp) 全部失败

所有非 CatBoost 模型 OOF ≈ 0.51 (近随机)。只有 CatBoost + RMSE 有效。
（参考解也独立确认了这一点。）

---

## 4. 过拟合风险评估

### 4.1 权重优化

3 个参数在 OOF 上优化:
- w_arm (arm1/arm2 权重): grid 0.30-0.79, step 0.02 → 固定 0.64
- w_te (byte TE 权重): grid 0.00-0.20, step 0.002 → 选 0.110
- w0 (byte0/byte7 比例): 固定 0.50 (不优化)

跨半迁移检验确认 lift 存活 (Section 1.6)，不是 OOF 过拟合。

### 4.2 OOF 诚实性

- arm1/arm2: 10-fold StratifiedKFold, 每 fold 的验证集 label 不参与训练 ✅
- ref: 5-fold, 同样原则 ✅
- byte0/7 TE: 5-fold fold-local, 验证集的 label 不参与自己的 TE ✅
- 无 test label 使用（test.csv 无 label 列）✅
- 无外部数据 ✅
- 无伪标签 ✅

### 4.3 独立审核结论

独立审核 agent (从 checkpoint 重建全部数字, 不信任任何日志):
- OOF 诚实性: **YES** (submission 与重建差异 1.11e-16)
- byte7 真实性: **YES** (20-seed cross-half, paired t=3.93)
- 过拟合风险: **LOW** (固定 w=0.10 的 held-out lift +0.00091 ± 0.00071, t=5.71)
- 数据泄漏: **NONE**
