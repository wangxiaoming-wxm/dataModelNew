#!/usr/bin/env bash
# 一键复现 v6_final 方案(完整,从数据重跑,~4 小时)
# 用法: bash reproduce.sh
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$(pwd)/src:${PYTHONPATH:-}"

echo "================================================"
echo "  复现 v6_final: max3(mo8 + ca8 + v6_b5v2_8raw)"
echo "  nested target = 0.70326 (含 ES 臂, 乐观上界)"
echo "  预计耗时: ~4 小时 (3 arms × 8 seeds × 5 fold)"
echo "================================================"

# 臂1: merger_ord8 (v2 主帧 + Ordered, depth=5, 8 seeds, ~95 min)
echo ""
echo "[1/4] 训练 merger_ord8..."
for c in 0 1 2 3; do
    echo "  --- chunk $c ---"
    python3 src/v2fe_ord_chunk.py "$c"
done
python3 src/combine_chunks.py merger_ord8 v2fe_ord_c0 v2fe_ord_c1 v2fe_ord_c2 v2fe_ord_c3

# 臂2: v2_cat_alt8 (v2 alt 编码世界, depth=6, 8 seeds, ~55 min)
echo ""
echo "[2/4] 训练 v2_cat_alt8..."
for c in 0 1 2 3; do
    echo "  --- chunk $c ---"
    python3 src/v2_cat_alt_chunk.py "$c"
done
python3 src/combine_chunks.py v2_cat_alt8 v2_cat_alt_c0 v2_cat_alt_c1 v2_cat_alt_c2 v2_cat_alt_c3

# 臂3: v6_b5v2 (B5 + v2 cond_r/ratio, depth=7, 8 seeds, ES, ~90 min)
echo ""
echo "[3/4] 训练 v6_b5v2 (ES arm, 内联 v2 特征)..."
for c in 0 1 2 3; do
    echo "  --- chunk $c ---"
    python3 src/v6_b5v2_chunk.py "$c"
done
echo "  --- combine (RAW average, 非 rank-pool!) ---"
python3 src/combine_raw.py v6_b5v2_8raw v6_b5v2_c0 v6_b5v2_c1 v6_b5v2_c2 v6_b5v2_c3

# 融合
echo ""
echo "[4/4] max3 融合 -> submission_v6_final.csv"
python3 src/fuse_v6.py

echo ""
echo "================================================"
echo "  完成。预期 nested = 0.70326 (乐观上界)"
echo "  提交文件: submissions/submission_v6_final.csv"
echo "  注意: label 不 clip, 范围 [~0.0002, ~1.0]"
echo "================================================"
