# vz17 方法详解

## 1. 问题

二分类保险理赔预测。train 14930 行 × 45 列（含 `label`），test 6398 行 × 44 列。
正例率约 10%。评测指标 AUC。

## 2. 整体结构

```
                ┌─ arm1: build_main ─ CatBoost(Ordered, d5, l2=10, rsm=1.0) ─┐
train+test ─────┤                                                            ├─ rank 融合 ─ byte0 TE ─ submission
                └─ arm2: build_alt  ─ CatBoost(Plain,   d6, l2=6,  rsm=0.3) ─┘
```

两个臂用**不同的特征世界**和**不同的模型配置**，保证多样性；再用 byte0 TE 做微调。

## 3. 特征工程（features.py）

所有统计量（分箱边界、source 中位数）在 **train+test 全集**上拟合（label-free，无泄漏）。

### build_main（arm1，cond_r 世界，~121 特征）
- `condition` 按 `source` 中位数标准化 → `cond_r`，再衍生 `ratio = days / cond_r`
- 数值：days/cond/ratio 的原始、log、分位数分箱
- 类别：region/source/month/version/grades/age + 二值列拼成的 `bin_pat`
- **手工类别交叉**（核心）：`d10|region`、`c10|source`、`region|source|age` 等数十个交互
- RATIO_COLS = `['V','cc','max_g','x17','x14']` 各自除以 cond_r

### build_alt（arm2，rate 世界，~100 特征）
- `condition` 按 `source` 百分位排名 → `rank`，衍生 `rate = days·(1-rank)`
- 数值：days/rank/rate 的原始、log、分位数分箱
- 类别交叉结构与 build_main 类似但变量名不同（`A` 前缀）

两个世界的差异本质：build_main 用**中位数标准化**（稳健），build_alt 用**百分位排名**（分布无关）。
两者在错误样本上有互补性（Pearson 相关 ≈ 0.94，不完美）。

## 4. 训练（train_catboost.py）

每个臂：
- 10-fold StratifiedKFold（shuffle, seed 2040-2047 共 8 个 fold-seed）
- 每 fold 内 3 个 bagging（random_seed = seed·100 + {0,1,2}）
- CatBoostRegressor，**RMSE loss**
- 总计 8 × 10 × 3 = 240 个模型/臂
- 输出 per-seed 的 OOF（rank-normalized）和 test 预测（rank-normalized）

### 为什么 RMSE 而非分类 loss
标签来自连续理赔额二值化。Logloss/CrossEntropy 的 OOF ≈ 0.51（近随机）；
RMSE 回归 OOF ≈ 0.70。回归 loss 更契合"连续信号被二值化"的结构。

### rsm=0.3 的作用（arm2 关键）
`rsm`（random subspace method）= 每 split 只用 30% 的特征。
arm2 的 build_alt 有 ~100 特征，其中大量类别交叉带来信号稀释。
rsm=0.3 强制每棵树只看部分特征，等价于强正则，扫描 `0.3 > 0.5 > 0.25 > 0.4 > 1.0`。
（arm1 用 Ordered boosting，自带 permutation-based 正则，rsm=0.3 额外提升 < 0.0004，故保持 1.0。）

## 5. 融合（build_vz17.py）

### Step A：双臂 rank-weighted
```
fuse = 0.64·rank(arm1_pooled) + 0.36·rank(arm2_pooled)
```
权重 0.64 由 OOF 网格搜索（0.30-0.80）确定，已固定。pooled = 8 seeds 的 rank 均值。

### Step B：byte0 折内 TE
```
byte0 = id_hash[0:2]  (0-255 的离散值)
byte0_TE = fold_local_target_encoding(byte0, label, 5-fold, seed=42)
```
折内编码：每 fold 的验证集用训练集的 `mean(label|byte0)` 编码，无泄漏。
对 test 用全集 `mean(label|byte0)`。

### Step C：三路融合
```
final = 0.98·fuse + 0.07·rank(byte0_TE)
```
权重在 OOF 上扫描确定后固定（w_cb ∈ [0.88,0.99]，w_b0 ∈ [0,0.12]）。
最终输出再 rank-normalize，clip 到 [0.001, 0.999]。

## 6. 为什么这套能 work

- **特征工程**：手工类别交叉捕捉 condition × region × age 的理赔倾向交互。
- **双臂多样性**：cond_r 世界（中位数标准化）与 rate 世界（百分位排名）互补。
- **rsm 正则**：解决类别交叉带来的特征稀释。
- **RMSE loss**：契合二值化前的连续信号。
- **byte0**：id 哈希本身携带的微弱但稳定的信号（可能是生成时的批次/时间结构）。

## 7. 已知局限（诚实）

- OOF 0.70170 → 线上 0.71487，gap 0.01317，是已知数据点中 gap 偏小的一端，
  说明 byte0 的 7% 混入在 test 上有轻微稀释，但因为权重小，影响可忽略。
- byte0 只在 **train 内部**（cross-half）验证为稳定信号；它是否在 test 上完全迁移，
  唯一的硬证据是"实际提交得 0.71487"本身，而非任何 train 内检验。
