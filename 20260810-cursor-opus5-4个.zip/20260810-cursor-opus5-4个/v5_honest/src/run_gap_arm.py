"""Score the B6 `gap` feature view as an extra, honestly-validated arm.

The view comes from insurance_claim/train_b6.build_gap (B5 features + fold-local
mining gap categorical crosses). Re-run here under an honest protocol: fixed
tree count (500), no early stopping. Its value is diversity — an independently
written encoding that decorrelates from the v2 main/alt views.

Honest: fixed 500 trees, no ES, fold-local feature fitting.

NOTE: sys.path points to local src/ (inlined insurance_claim, self-contained).
NOTE: This arm uses seeds 20290-20293 (4 seeds, NOT 8). This is fewer than the
  other two arms (8 seeds each), so its OOF is slightly noisier.

Output: artifacts/arm_gap.npz (oof, test, y)
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from scipy.stats import rankdata
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

sys.path.insert(0, str(Path(__file__).resolve().parent))
from insurance_claim.train_b6 import build_gap  # noqa: E402

DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
ART = Path(__file__).resolve().parent.parent / "artifacts"

PARAMS = dict(loss_function="Logloss", learning_rate=0.03, depth=6, l2_leaf_reg=10,
              random_strength=0.7, verbose=False, thread_count=4,
              allow_writing_files=False, iterations=500)

SEEDS = [20290, 20291, 20292, 20293]
FOLDS = 5


def main() -> int:
    train = pd.read_csv(DATA / "train.csv")
    test = pd.read_csv(DATA / "test.csv")
    y = train["label"].to_numpy()
    feats = train.drop(columns=["label"])
    ART.mkdir(parents=True, exist_ok=True)

    oof_seeds, test_parts, t_start = [], [], time.time()
    for seed in SEEDS:
        t0 = time.time()
        oof = np.zeros(len(y))
        for f, (ti, vi) in enumerate(
            StratifiedKFold(FOLDS, shuffle=True, random_state=seed).split(feats, y)
        ):
            Xtr, Xva, Xte, cats = build_gap(
                feats.iloc[ti].reset_index(drop=True),
                feats.iloc[vi].reset_index(drop=True),
                test.copy(),
            )
            m = CatBoostClassifier(**PARAMS, random_seed=seed + f)
            m.fit(Xtr, y[ti], cat_features=cats, verbose=False)
            oof[vi] = m.predict_proba(Xva)[:, 1]
            pt = m.predict_proba(Xte)[:, 1]
            test_parts.append(rankdata(pt) / len(pt))
        oof_seeds.append(rankdata(oof) / len(oof))
        print(f"  gap seed={seed} oof={roc_auc_score(y, oof):.5f} ({time.time() - t0:.0f}s)",
              flush=True)

    oof = np.mean(oof_seeds, axis=0)
    pred = np.mean(test_parts, axis=0)
    np.savez_compressed(ART / "arm_gap.npz", oof=oof, test=pred, y=y)
    summary = {
        "seeds": SEEDS,
        "bagged_oof_auc": float(roc_auc_score(y, oof)),
        "per_seed_auc": [float(roc_auc_score(y, o)) for o in oof_seeds],
        "elapsed_sec": round(time.time() - t_start, 1),
    }
    (ART / "gap_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
