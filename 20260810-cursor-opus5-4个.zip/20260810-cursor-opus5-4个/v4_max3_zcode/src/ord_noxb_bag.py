"""8-seed bag of Ordered boosting on B5 base features WITHOUT x0:x18 bins.

ord_noxb was the only round-2 probe to improve blend4 (+0.000148, weight 0.10).
Its errors are orthogonal to plus (corr 0.872) — a genuine 5th ensemble arm.
This bags 8 seeds so it's a strong standalone contributor, not just a single seed.

NOTE: This arm uses use_best_model=True (early stopping on the validation fold).
  - OOF AUC is OPTIMISTIC (+~0.0015 bias) because ES peeks at the val fold.
  - TEST predictions are HONEST (ES never sees the test set).
  So this arm's OOF cannot be used as an unbiased metric, but its test_pred
  is valid for submission fusion. See README §"ES bias".

NOTE: sys.path now points to local src/ (inlined insurance_claim, self-contained).
"""
from __future__ import annotations
import sys, warnings, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier
from insurance_claim.train_b5_focus import VIEWS
from insurance_claim.model import TARGET

DATA = Path("/Volumes/pssd/app/ml/正式比赛/data")
ART = Path(__file__).resolve().parent.parent / "artifacts"
SEEDS = (2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033)


def run():
    train = pd.read_csv(DATA / "train.csv")
    test = pd.read_csv(DATA / "test.csv")
    y = train[TARGET].astype(int)
    builder, b5p = VIEWS["b5"]
    p = {k: v for k, v in b5p.items() if k != "random_seed"}
    p.pop("l2_leaf_reg", None)
    p.update(depth=7, iterations=1200, boosting_type="Ordered")
    features = train.drop(columns=[TARGET])
    pooled_oof = np.zeros(len(train))
    pooled_te = np.zeros(len(test))
    per_seed = []
    t_all = time.time()
    for seed in SEEDS:
        oof_s = np.zeros(len(train))
        te_s = np.zeros(len(test))
        t0 = time.time()
        for fold, (tri, vai) in enumerate(
            StratifiedKFold(5, shuffle=True, random_state=seed).split(features, y)
        ):
            Xtr = features.iloc[tri].reset_index(drop=True)
            Xva = features.iloc[vai].reset_index(drop=True)
            Xte = test.copy()
            ytr = y.iloc[tri].reset_index(drop=True)
            yva = y.iloc[vai].reset_index(drop=True)
            tr_df, va_df, te_df, cats = builder(Xtr, Xva, Xte)  # NO xbin
            m = CatBoostClassifier(**dict(p, random_seed=seed + fold))
            m.fit(tr_df, ytr, eval_set=(va_df, yva), cat_features=cats,
                  use_best_model=True, verbose=False)
            oof_s[vai] = m.predict_proba(va_df)[:, 1]
            te_s += m.predict_proba(te_df)[:, 1] / 5
        a = roc_auc_score(y, oof_s)
        per_seed.append(a)
        print(f"[ord_noxb_bag] seed {seed}: OOF={a:.6f} ({time.time()-t0:.0f}s)", flush=True)
        pooled_oof += oof_s
        pooled_te += te_s
    pooled_oof /= len(SEEDS)
    pooled_te /= len(SEEDS)
    pool_auc = roc_auc_score(y, pooled_oof)
    print(f"\n[ord_noxb_bag] {len(SEEDS)}-seed pooled OOF = {pool_auc:.6f}  "
          f"(per-seed {np.mean(per_seed):.6f} ± {np.std(per_seed):.6f})  "
          f"total {time.time()-t_all:.0f}s", flush=True)
    np.savez(ART / "ord_noxb_bag.npz", oof=pooled_oof, test_pred=pooled_te,
             per_seed=np.array(per_seed), seeds=np.array(SEEDS))
    return pool_auc


if __name__ == "__main__":
    run()
